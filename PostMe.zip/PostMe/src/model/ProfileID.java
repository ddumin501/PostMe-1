package model;

public class ProfileID {
	public static String id="";
}

