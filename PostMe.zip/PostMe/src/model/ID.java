package model;

public class ID {
	public static String id="";

}
